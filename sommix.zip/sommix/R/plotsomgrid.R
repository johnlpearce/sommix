#Generate Base Plot
#'\code{plot.somgrid} sets plot base
#'@param x a SOM object
#'@param xlim sets x limits
#'@param ylim sets y limits
#'@return sets up base plot frame
#'@export
plot.somgrid <- function(x, xlim, ylim, ...){
  ## The following two lines leave equal amounts of space on both
  ## sides of the plot if no xlim or ylim are given
  if (missing(xlim)) xlim <- c(0, max(x$pts[,1]) + min(x$pts[,1]))
  if (missing(ylim)) ylim <-  c(max(x$pts[,2]) + min(x$pts[,2]), 0)
  eqscplot(xlim, ylim, axes = FALSE,
           type = "n", xlab = "", ylab = "", ...)
}
