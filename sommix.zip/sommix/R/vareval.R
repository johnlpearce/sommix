#VarEval
#Author: John Pearce

############################################################################################
#A Collection of functions to explore data characteristics
############################################################################################
#'Explores statistical characteristics of each variable independently and provides summary table'
#'@export
var.eval<-function(data, lab.cex=0.75, sym.cex=2){
  #Set up data
  data=data
  vars=names(data)

  #Set plot specifics
  var.labs=ifelse(nchar(vars)<8,vars,substr(vars, 0,8))
  lab.cex=lab.cex

  #Evaluate Variable completeness
  NAs<-apply(apply(data,2,is.na),2,sum)
  NAs.per<-round(100*(NAs/dim(data)[1]),2)
  N<-apply(apply(data,2,complete.cases),2,sum)
  N.per<-round(100*(N/dim(data)[1]),2)

  ZERO<-function (x){length(which(x <= 0))}
  ZEROs<-round(apply(data,2,FUN=ZERO),2)
  ZEROs.per<-round(100*(ZEROs/dim(data)[1]),2)

  AVG<-round(apply(data,2,FUN=mean, na.rm=TRUE),5)
  MED<-round(apply(data,2,FUN=median, na.rm=TRUE),5)
  SD<-round(apply(data,2,FUN=sd, na.rm=TRUE),5)
  CV<-SD/AVG
  CVrank=rank(-CV, ties.method = "random")
  MN<-round(apply(data,2,FUN=min, na.rm=TRUE),5)
  Q1<-round(apply(data,2,FUN=quantile, na.rm=TRUE)[2,],5)
  Q3<-round(apply(data,2,FUN=quantile, na.rm=TRUE)[4,],5)
  IR=round(apply(data,2,FUN=IQR, na.rm=TRUE),5)
  MX<-round(apply(data,2,FUN=max, na.rm=TRUE),5)


  summ.tab<-cbind(N, N.per, NAs, NAs.per, ZEROs, ZEROs.per, AVG, MED, SD, CV, CVrank, MN, Q1, MED, Q3, MX, IR)

  #Evaluate variable distribution
  SK<-NULL
  KR<-NULL

  for (i in 1:dim(data)[2]){
    #Set variable
    V1<-as.numeric(na.omit(data[,i]))

    #Generate Distributional Statistics
    sk<-skewness(V1)
    kr<-kurtosis(V1, type=2)

    #Populate Summaries
    SK<-c(SK,sk)
    KR<-c(KR,kr)

  }

  summ.tab<-data.frame(VARIABLE=vars,summ.tab, Skewness=SK, Kurtosis=KR)
  write.table(x=summ.tab, file="var.eval.summ.tab.csv", sep=",", row.names=FALSE)

  #############################################################
  #Evaluation Plots
  par(mfrow=c(3,2), mar=c(4,4,1.5,1), family="serif", xaxs="r", ask=FALSE, cex=0.75)

  plot(summ.tab$Skewness, pch=20, col="darkblue", ylab="Skewness",
       xlab="", main="b) Skewness", xaxt="n", cex=sym.cex)
  axis(side=1, at=1:length(vars), labels=var.labs, las=2, cex.axis=lab.cex)
  abline(h=c(0), col=c("lightgrey"), lwd=2, lty=2)

  plot(summ.tab$Kurtosis, pch=20, col="darkblue", ylab="Kurtosis",
       xlab="", main="b) Kurtosis", xaxt="n", cex=sym.cex)
  axis(side=1, at=1:length(vars), labels=var.labs, las=2, cex.axis=lab.cex)
  abline(h=0, col="lightgrey", lwd=2, lty=2) #Values below 0.05 not normal


  plot(summ.tab$SD, pch=20, col="darkblue", ylab="Standard Deviation",
       xlab="", main="c) Standard Deviations", xaxt="n", cex=sym.cex)
  axis(side=1, at=1:length(vars), labels=var.labs, las=2, cex.axis=lab.cex)
  abline(h=c(0), col=c("lightgrey"), lwd=2, lty=2)

  plot(summ.tab$CV, pch=20, col="darkblue", ylab="mean/sd",
       xlab="", main="d) Coefficient of Variation (CV)",
       xaxt="n", cex=sym.cex)
  axis(side=1, at=1:length(vars), labels=var.labs, las=2, cex.axis=lab.cex)
  abline(h=c(1), col=c("lightgrey"), lwd=2, lty=2)

  plot(summ.tab$NAs.per, pch=20, col="darkblue", ylab="Percentage",
       xlab="", main="e) Missing Values (%)", ylim=c(0,100), xaxt="n",
       cex=sym.cex)
  axis(side=1, at=1:length(vars), labels=var.labs, las=2, cex.axis=lab.cex)
  abline(h=c(90), col=c("lightgrey"), lwd=2, lty=2)

  plot(summ.tab$ZEROs.per, pch=20, col="darkblue", ylab="Percentage",
       xlab="", main="f) Values less than or equal to zero (%)", ylim=c(0,100), xaxt="n",
       cex=sym.cex)
  axis(side=1, at=1:length(vars), labels=var.labs, las=2, cex.axis=lab.cex)
  abline(h=c(90), col=c("lightgrey"), lwd=2, lty=2)

  print.tab=summ.tab[,c("VARIABLE", "N", "AVG", "SD", "MN", "Q1", "MED","Q3", "MX", "IR",  "CV", "CVrank")]
  print.tab

}
