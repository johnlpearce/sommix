
############################################################################################
#'Apply Functions to generate SOM evaluation statisticss
#'
#'\code{somSSS} estimates som model sum of squares
#'@param som.obj a som object
#'@return a list of values
#'@export
somSSS<-function(som.obj){
  x=data.frame(som.obj$data)
  k=as.factor(som.obj$unit.classif)

  #Set range of functions to evaluate sum-of-squares
  #Total Sum of Squares
  TSS <- sum(scale(x, scale = FALSE)^2)

  #Within-class sum of squares
  k.n<-length(levels(k))
  WCSS=NULL

  for (i in 1:k.n){
    x1=subset(x, k==i)
    wss<-sum(scale(x1, scale = FALSE)^2)
    WCSS<-c(WCSS, wss)
  }

  #Total sum of within-class sum-of-squares
  Tot.WCSS<-sum(WCSS)

  #Between class sum of squares
  BCSS<-TSS-Tot.WCSS

  sumofsquares=list("TotalSumSquares"=TSS, "WithinClassSumSquares"=WCSS, "TotWithnClassSumSquares"=Tot.WCSS, "BetweenClassSumSquares"=BCSS)
  return(sumofsquares)
}

#'\code{somR2} estimates som model r-square
#'@param som.obj a som object
#'@return a list of values
#'@export
somR2<-function(som.obj){
  x=data.frame(som.obj$data)
  k=as.factor(som.obj$unit.classif)

  #Set range of functions to evaluate sum-of-squares
  #Total Sum of Squares
  TSS <- sum(scale(x, scale = FALSE)^2)

  #Within-class sum of squares
  k.n<-length(levels(k))
  WCSS=NULL

  for (i in 1:k.n){
    x1=subset(x, k==i)
    wss<-sum(scale(x1, scale = FALSE)^2)
    WCSS<-c(WCSS, wss)
  }

  #Total sum of within-class sum-of-squares
  Tot.WCSS<-sum(WCSS)

  #Between class sum of squares
  BCSS<-TSS-Tot.WCSS

  #Within-Between Ratio
  Pseudo.F<-BCSS / Tot.WCSS


  rsq=BCSS/TSS

  return(rsq)
}

#'\code{somFstat} estimates a Pseudo F stat for som model
#'@param som.obj a som object
#'@return a Pseudo F value
#'@export
somFstat<-function(som.obj){
  x=data.frame(som.obj$data)
  k=as.factor(som.obj$unit.classif)

  #Set range of functions to evaluate sum-of-squares
  #Total Sum of Squares
  TSS <- sum(scale(x, scale = FALSE)^2)

  #Within-class sum of squares
  k.n<-length(levels(k))
  WCSS=NULL

  for (i in 1:k.n){
    x1=subset(x, k==i)
    wss<-sum(scale(x1, scale = FALSE)^2)
    WCSS<-c(WCSS, wss)
  }

  #Total sum of within-class sum-of-squares
  Tot.WCSS<-sum(WCSS)

  #Between class sum of squares
  BCSS<-TSS-Tot.WCSS

  #Within-Between Ratio
  Pseudo.F<-BCSS / Tot.WCSS

  return(Pseudo.F)
}


#'\code{somAIC} estimates a Pseudo AIC stat for som model
#'@param som.obj a som object
#'@return a Pseudo AIC value
#'@export
somAIC <-function(som.obj){

  m = ncol(data.frame(som.obj$codes))
  n = length(som.obj$unit.classif)
  p = nrow(data.frame(som.obj$codes))

  x=data.frame(som.obj$data)
  k=as.factor(som.obj$unit.classif)

  #Set range of functions to evaluate sum-of-squares
  #Total Sum of Squares
  TSS <- sum(scale(x, scale = FALSE)^2)

  #Within-class sum of squares
  k.n<-length(levels(k))
  WCSS=NULL

  for (i in 1:k.n){
    x1=subset(x, k==i)
    wss<-sum(scale(x1, scale = FALSE)^2)
    WCSS<-c(WCSS, wss)
  }

  #Total sum of within-class sum-of-squares
  Tot.WCSS<-sum(WCSS)

  #Between class sum of squares
  BCSS<-TSS-Tot.WCSS

  D = Tot.WCSS

  AIC = D + 2*m*p

  return(AIC)
}
