#Develop a set of functions to evaluate a range of common Self-Organizing Map sizes
#'Explores map size with a variety of statistical learning approaches
#'\code{map.size.eval} explores map size
#'@param data a data object
#'@param kmx sets maximum number of groups to map
#'@param nstart sets number of seed values to assess
#'@param iter.max sets number of iterations for each SOM implementation
#'@param grid.topo specifies map grid topology
#'@return plots of map size results a list with results
#'@export


map.size.eval<-function(data, kmx, nstart=10, iter.max=100,
                        grid.topo="rectangular"){

  #Set common dimensions
  som.x=c(2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15,16,16,17,17,18,18,19,19,20,20)
  som.y=c(2,2,3,3,4,4,5,5,6,6,7,7,8,8,9, 9,10,10,11,11,12,12,13,13,14,14,15,15,16,16,17,17,18,18,19,19,20)
  som.xy=som.x*som.y

  max.size<-which(abs(som.xy-kmx)==min(abs(som.xy-kmx)))

  #set Data
  data=data
  var.names=names(data.frame(data))
  n.vars=length(var.names)
  n.obs=dim(data)[1]

  MOD.TAB<-data.frame()
  EVAL.TAB<-data.frame()
  FREQ.TAB<-data.frame()
  MAP.TAB<-data.frame()


  for (i in 1:max.size){
    somx=som.x[i]
    somy=som.y[i]

    data=data.matrix(data)

    #Identify optimal seed value
    opt.seed<-som.seed(data=data, nstart=nstart, iter.max=iter.max, somx=somx, somy=somy, grid.topo=grid.topo)

    #Apply a SOM
    set.seed(opt.seed)
    som.mod<-som(X=data, grid=somgrid(somx,somy,grid.topo),
                 rlen=iter.max, alpha=c(0.05, 0.01))
    som.summ=som.fit.summ(som.mod)

    mod.tab=data.frame(SOMX=somx, SOMY=somy, k=somx*somy,
                       R2=as.numeric(som.summ$MODEL_STATS$R2),
                       QE=as.numeric(som.summ$MODEL_STATS$QE),
                       RMSE=as.numeric(som.summ$MODEL_STATS$RMSE))

    eval.tab<-data.frame(VAR.NAM=var.names,SOMX=somx, SOMY=somy, k=somx*somy,
                         R.P=som.summ$COMPONENT_EVALUATION$R,
                         RMSE.P=som.summ$COMPONENT_EVALUATION$RMSE,
                         MAE.P=som.summ$COMPONENT_EVALUATION$MAE)

    freq.tab<-data.frame(SOMX=somx, SOMY=somy,k=somx*somy,
                         N=as.numeric(som.summ$FREQUENCIES$N),
                         FREQ=as.numeric(som.summ$FREQUENCIES$FREQ))

    map.tab<-data.frame(VAR.NAM=var.names,SOMX=somx, SOMY=somy,k=somx*somy,
                        MI=som.summ$MAP_ORGANIZATION$`Morans I`,
                        MI_P=som.summ$MAP_ORGANIZATION$MI_Pval,
                        GC=som.summ$MAP_ORGANIZATION$`Gearys C`,
                        GC_Pval=som.summ$MAP_ORGANIZATION$GC_Pval)

    MOD.TAB<-rbind(MOD.TAB,mod.tab)
    EVAL.TAB<-rbind(EVAL.TAB, eval.tab)
    FREQ.TAB<-rbind(FREQ.TAB,freq.tab)
    MAP.TAB<-rbind(MAP.TAB, map.tab)

  }

  #Plots
  par(mfrow=c(3,2), mar=c(3,4,1.5,1), family='serif', ask=FALSE, cex=0.75, pty="m")

  plot(MOD.TAB$RMSE~MOD.TAB$k, ylab="Distance", xlab="Number of profiles (k)",
       main="a) Map RMSE", type="b", pch=19, cex=1, col="darkgrey",
       ylim=c(0,max(MOD.TAB$RMSE)*1.2))

  plot(MOD.TAB$R2~MOD.TAB$k, ylab="BCSS/TSS", xlab="Number of profiles (k)",
       main="b) Map R-square", type="b", pch=19, cex=1, col="darkgrey",
       ylim=c(0,1))

  boxplot(EVAL.TAB$R.P~EVAL.TAB$k, ylab="R", xlab="Number of profiles (k)",
          main="c) Variablewise Correlations", ylim=c(-1,1))

  boxplot(EVAL.TAB$RMSE.P~EVAL.TAB$k, ylab="RMSE", xlab="Number of profiles (k)",
          main="d) Variablewise RMSE", ylim=c(0,max(EVAL.TAB$RMSE)*1.2))

  boxplot(FREQ.TAB$N~FREQ.TAB$k, ylab="N", xlab="Number of profiles (k)",
          main="e) Profile Frequency Distributions")

  boxplot(MAP.TAB$MI~MAP.TAB$k, ylab="Moran's I", xlab="Number of profiles (k)",
          main="f) Variablewise Map Organization")

  #Generate Tabular output
  MAP.EVAL<-list(MOD.FIT=MOD.TAB, VAR.FIT=EVAL.TAB, MAP.FREQ=FREQ.TAB, MAP.STRUCTURE=MAP.TAB)
  MAP.EVAL
}
##########################################################
