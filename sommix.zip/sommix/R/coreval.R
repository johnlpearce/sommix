############################################################################################
#'Apply Functions to explore data correlations
#'\code{cor.eval} explores statistical correlations of variables
#'@param data a data object
#'@param cor.method passes correlation method to cor()
#'@param lab.cex sets label size
#'@return a dataframe object
#'@export
cor.eval<-function(data, cor.method="pearson", lab.cex=0.75){

  #Set up data
  data=data
  vars=names(data)

  #Set plot specifics

  var.labs=ifelse(nchar(vars)<8,vars,substr(vars, 0,8))
  lab.cex=lab.cex

  par(mfrow=c(1,1), mar=c(5,4,2,1), family='serif', cex=lab.cex, ask=FALSE, pty="m")

  #Examine group structure via distribution of pairwise distances between objects
  #Identy pairwise correlations
  cor.method="pearson"
  cor.mat<-cor(data, method=cor.method, use="pairwise.complete.obs")

  write.table(x=cor.mat, file="cor.summ.tab.csv", sep=",")
  cat("*******************************************************************",
      "\n")
  cor.summ=round(data.frame(cor.mat),2)
  cor.summ[upper.tri(cor.mat, diag=TRUE)]<-NA
  print(cor.summ)
  cat("*******************************************************************",
      "\n")

  col.r <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
  corrplot(cor.mat, method="color", col=rev(col.r(200)),type="lower",
           order="original", tl.cex=lab.cex,
           tl.col="black", tl.srt=45,
           diag=FALSE)
}
############################################################################################
