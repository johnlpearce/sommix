#Find optimal seed value
#'Identified optimal seed value for SOM
#'\code{som.seed} identified optimal seed value
#'@param data a data object
#'@param nstart sets number of random initializations
#'@param iter.max sets number of iterations for each SOM implementation
#'@param somx x dimension of SOM
#'@param somy y dimension of SOM
#'@param grid.topo specification of map topology passed to somgrid
#'@return optimal seed value
#'@export
som.seed<-function(data, nstart=10, iter.max=100, somx, somy, grid.topo="rectangular"){
  #Set random initializations
  set.seed(1)
  ran.inits=sample(1:100,nstart)
  ran.inits
  #Set eval object
  init.eval<-NULL

  for(i in 1:nstart){
    set.seed(ran.inits[i])
    ex.som<-som(X=data.matrix(data), grid=somgrid(somx,somy,grid.topo),
                rlen=iter.max, mode="online", dist.fcts="euclidean")
    QE=mean(ex.som$distances)
    init.eval=c(init.eval,QE)
  }

  seed.value=ran.inits[which(init.eval == min(init.eval))]
  return(seed.value)
}
