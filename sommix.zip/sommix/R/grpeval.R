############################################################################################
#Explore grouping structure (i.e., clustering) strategies applied in cluster anaylsis

#'Explores grouping structure with a variety of cluster analysis approaches
#'\code{grp.eval} explores grouping structure among variables
#'@param data a data object
#'@param kmn sets minimum number of groups
#'@param kmx sets maximum number of groups
#'@param iter.max sets number of iterations for each SOM implementation
#'@return plots of grouping results and dataframe of results
#'@export
grp.eval<-function(data, kmn, kmx, iter.max=100){
  #Set data
  data=data.matrix(data)
  #set Data distance matrix
  dist.mat<-data.matrix(dist(x=data, method="euclidean"))

  AW=NULL
  AB=NULL
  CH=NULL
  ASW=NULL


  for (i in kmn:kmx){
    set.seed(1000)
    ex.som<-som(X=data, grid=somgrid(xdim=i, ydim=1, topo=c("rectangular")),
                rlen=iter.max, mode="online", dist.fcts="euclidean")
    #SOM-based classifications
    som.class=ex.som$unit.classif


    CLUSTER.STATS=cluster.stats(d=dist.mat, clustering=as.integer(som.class))

    #Cluster Cohesion
    aw=CLUSTER.STATS$average.within

    #Cluster Seperation
    ab=CLUSTER.STATS$average.between

    #Calinski-Harabasz Index
    ch=CLUSTER.STATS$ch

    #Silhoutte Width
    sw.summ=CLUSTER.STATS$clus.avg.silwidths
    sw.summ
    asw=CLUSTER.STATS$avg.silwidth

    AW=c(AW, aw)
    AB=c(AB,ab)
    CH=c(CH,ch)
    ASW=c(ASW,asw)

  }

  #Examine group structure using common cluster statistics
  CLUST.EVAL<-data.frame(K=seq(kmn,kmx,1), WITHIN=AW, BETWEEN=AB, CalH=CH, SilW=ASW)
  write.table(x=CLUST.EVAL, file="cluster.stats.csv", row.names=F, sep=",")

  par(mfrow=c(3,2), mar=c(3,4,1.5,1), cex=0.75, family='serif', pty="m")

  #Examine group structure via distribution of pairwise distances between objects
  hist(dist.mat, main="a) Pairwise Object Distances", xlab="Euclidean Distance",
       cex=1, col="lightgrey")
  box()
  box(which="outer")

  #Apply multidimensional scaling to visualize clustering structure
  loc <- cmdscale(dist.mat)
  x <- loc[, 1]
  y <- -loc[, 2] # reflect so North is at the top
  ## note asp = 1, to ensure Euclidean distances are represented correctly
  plot(x, y, type = "p", xlab = "MDS X", ylab = "MDS Y", asp = 1, axes = TRUE,
       main = "b) Multi-dimensional Scaling", pch=20, col="darkblue")
  #text(x, y, rownames(loc), cex = 0.6)
  box()
  box(which="outer")

  ##########################################################################
  #Create Plots
  plot(x=CLUST.EVAL[,"K"], y=CLUST.EVAL[,"WITHIN"], pch=20, col="darkblue", xlab="Number of profiles (k)",
       ylab="Distance", main="c) Average Within-Distance ",type="b")

  plot(x=CLUST.EVAL[,"K"], y=CLUST.EVAL[,"BETWEEN"], pch=20, col="darkblue", xlab="Number of profiles (k)",
       ylab="Distance", main="d) Average Between-Distance ",type="b")

  plot(x=CLUST.EVAL[,"K"], y=CLUST.EVAL[,"CalH"], pch=20, col="darkblue", xlab="Number of profiles (k)",
       ylab="Pseudo F-Statistic", main="e) Calinski Harabaz ",type="b")

  plot(x=CLUST.EVAL[,"K"], y=CLUST.EVAL[,"SilW"], pch=20, col="darkblue", xlab="Number of profiles (k)",
       ylab="Avg Width", main="f) Avg Silhouette Width ",type="b", ylim=c(-1,1))



  cat("*******************************************************************",
      "\n")
  #print(CLUST.EVAL)
  cat("*******************************************************************",
      "\n")
  CLUST.EVAL
 }
############################################################################################
