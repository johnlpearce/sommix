#Summary Function to for summarizing and assessing SOM via kohonen package
#'Apply Functions to explore SOM output
#'\code{som.fit.summ} explores statistical correlations of variables
#'@param som.obj a SOM object
#'@return a list object
#'@export


som.fit.summ<-function(som.obj){

  #########################################################################
  #Extract Model Stats
  somr2=somR2(som.obj)
  somaic=somAIC(som.obj)
  somfstat=somFstat(som.obj)
  QE<-mean(som.obj$distances)
  RMSE<-sqrt(mean(som.obj$distances^2))

  mod.stats=data.frame(QE, "R2"=somr2, RMSE)

  #########################################################################
  #Extract Training Data
  data=data.frame(som.obj$data)
  var.names<-names(data)

  #########################################################################
  #Extract SOM dimensions and create labels
  somx=som.obj$grid$xdim
  somy=som.obj$grid$ydim
  som.k=somx*somy
  XYs=paste(round(som.obj$grid$pts[,1],2),round(som.obj$grid$pts[,2],2), sep="")
  SOM_IDs=1:som.k
  #SOM Coordinates and reference table
  som.coords<-data.frame(X=som.obj$grid$pts[,1],Y=som.obj$grid$pts[,2])
  som.class.xy<-data.frame(SOM_ID=factor(SOM_IDs), XY=factor(XYs),X=as.numeric(som.obj$grid$pts[,1]),
                           Y=as.numeric(som.obj$grid$pts[,2]))

  #########################################################################
  #Extract SOM Profiles
  profiles<-data.frame(som.obj$codes)
  row.names(profiles)<-SOM_IDs

  #########################################################################
  #Create data frame with SOM classifications and predictions
  som.class<-som.obj$unit.classif
  class.tab<-data.frame(OBS=1:length(som.class), SOM_ID=som.class)

  class.tab2<-merge(class.tab, som.class.xy, by="SOM_ID")
  class.tab2<-class.tab2[,c("OBS", "SOM_ID","XY","X","Y")]
  class.tab3<-class.tab2[do.call(order,class.tab2),]
  class.tab3$ERROR<-som.obj$distances
  rownames(class.tab3)<-class.tab3$OBS

  profiles2<-data.frame(SOM_ID=rownames(profiles), profiles)
  som.preds<-merge(class.tab3, profiles2, by="SOM_ID",all.x=TRUE)

  som.variable<-som.preds[order(som.preds$OBS),]


  #########################################################################
  #Frequency Summary
  som.n<-table(class.tab$SOM_ID)
  som.freq<-round(100*(table(class.tab$SOM_ID)/sum(table(class.tab$SOM_ID))),2)

  freq.tab<-data.frame(som.n, som.freq)
  freq.tab2<-merge(som.class.xy, freq.tab, by.x="SOM_ID", by.y="Var1", all.x=TRUE)
  freq.tab2$Var1.1<-NULL
  colnames(freq.tab2)<-c("SOM_ID","XY","X","Y","N","FREQ")
  freq.tab2<-freq.tab2[order(as.numeric(freq.tab2$SOM_ID)),]


  #########################################################################
  #Internal evaluation of SOM Fit using distance measures
  QE<-mean(som.obj$distances)
  error<-aggregate(x=som.obj$distances, by=list(som.obj$unit.classif), FUN=mean, na.omit=TRUE)
  error.tab<-data.frame(error)
  colnames(error.tab)<-c("SOM_ID", "WITHIN")
  error.tab2<-merge(som.class.xy,error.tab, by.x="SOM_ID", by.y="SOM_ID", all.x=TRUE)
  profile.dist<-data.matrix(dist(data.frame(som.obj$codes)))
  profile.dist2<-apply(profile.dist, MARGIN=1, FUN=mean, na.rm=TRUE)
  error.tab2$BETWEEN<-profile.dist2
  error.tab2$WB.RATIO=error.tab2$WITHIN/error.tab2$BETWEEN
  error.tab3<-error.tab2[order(as.numeric(error.tab2$SOM_ID)),]

  #Extract cluster' evaluation statistics for each SOM profile
  dist.summ<-error.tab3

  #########################################################################
  #Construct Evaluation Data Sets
  data.eval=data.frame(class.tab, data)
  data.eval.xy<-merge(data.eval, som.class.xy, by="SOM_ID")
  data.eval.xy.preds<-merge(data.eval.xy, som.preds, by="OBS",
                            suffixes=c("",".p"))

  #########################################################################
  #Variable statistics for SOM-based predictions
  ## Evaluate discriminatory power of SOM-based profiles scores
  R.p=NULL
  RMSE.p=NULL
  MAE.p=NULL

  #Asses correlation and precision measures
  for (j in 1:length(var.names)){
    var.n=var.names[j]
    D1<-data.eval.xy.preds
    Y=D1[,var.n]
    X=D1[,paste(var.n, ".p", sep="")]

    #Identify Correlation
    r.p<-cor(Y,X, method="pearson")

    #Extract RMSE
    err.p<-Y-X
    rmse.p<-round(sqrt(mean(err.p^2)),4)
    mae.p<-round(mean(abs(err.p)),4)
    RMSE.p<-c(RMSE.p, rmse.p)
    MAE.p<-c(MAE.p, mae.p)
    R.p<-c(R.p,round(r.p,2))
  }

  var.eval<-data.frame(VARS=var.names,R.P=as.numeric(R.p),
                       RMSE.P=RMSE.p, MAE.P=MAE.p)

  var.eval$R_P_Rank<-rank(-var.eval$R.P)
  var.eval$RMSE_P_Rank<-rank(var.eval$RMSE.P)
  var.eval$MAE_P_Rank<-rank(var.eval$MAE.P)

  colnames(var.eval)<-c("Variable", "R","RMSE", "MAE",
                        "R_Rank","RMSE_Rank","MAE_Rank")


  #########################################################################
  #Evaluate 'spatial'organization of map via global tests of spatial autocorrelation
  if (somy>1){
    #Convert grid to spatial coordinates
    som.xy<-SpatialPoints(som.coords)

    #Global Network
    som.knn<-knn2nb(knearneigh(som.xy, k=round(som.k*.2, 0)))
    #Neighborhood Distances
    som.dist<-unlist(nbdists(som.knn, coords=som.xy))

    MI=NULL
    MI_P=NULL
    GI=NULL
    GI_P=NULL

    for (j in 1:length(var.names)){
      if (sd(profiles[,j]) > 0) {
        mt<-moran.test(x=profiles[,j], nb2listw(som.knn), na.action=na.exclude)
        mi<-as.numeric(mt$statistic)
        mi.p<-as.numeric(mt$p.value)

        gt<-geary.test(x=profiles[,j], nb2listw(som.knn))
        gi<-as.numeric(gt$statistic)
        gi.p<-as.numeric(gt$p.value)
      } else {
        mi=NA
        mi.p=NA
        gi=NA
        gi.p=NA
      }

      MI<-c(MI, mi)
      MI_P<-c(MI_P, mi.p)
      GI<-c(GI,gi)
      GI_P<-c(GI_P,gi.p)
    }

    sp.cor.tab<-data.frame(var.names,MI, MI_P, GI, GI_P)
    colnames(sp.cor.tab)<-c("Variable", "Morans I", "MI_Pval", "Gearys C", "GC_Pval")
    sp.cor.tab$MI_Rank<-rank(-sp.cor.tab$`Morans I`)
    sp.cor.tab$GI_Rank<-rank(-sp.cor.tab$`Gearys C`)

    #print("Map Structure/Autocorrelation Evaluation Complete")
  } else { sp.cor.tab<-NA}


  #########################################################################
  #Summarize training data by each SOM Class
  D2<-data

  #Identify SOM Class Assignments
  GRP<-som.obj$unit.classif
  N<-table(GRP)
  FREQ<-round(100*(N/sum(N)),1)

  means<-aggregate(x=D2[,var.names], by=list(GRP), FUN=mean, na.rm=TRUE)
  means<-round(means[,-1],2)

  med<-aggregate(x=D2[,var.names], by=list(GRP), FUN=median, na.rm=TRUE)
  med<-round(med[,-1],2)

  stdev<-aggregate(x=D2[,var.names], by=list(GRP), FUN=sd, na.rm=TRUE)
  stdev<-round(stdev[,-1],2)

  stderr <- function(x, na.rm=FALSE) {
    if (na.rm) x <- na.omit(x)
    sqrt(var(x)/length(x))
  }

  std.err<-aggregate(x=D2[,var.names], by=list(GRP), FUN=stderr, na.rm=TRUE)
  std.err<-round(std.err[,-1],2)

  cv<-function (x) {sd(x)/mean(x)}

  CVar<-aggregate(x=D2[,var.names], by=list(GRP), FUN=cv)
  CVar<-round(CVar[,-1],2)

  mnv<-aggregate(x=D2[,var.names], by=list(GRP), FUN=min)
  mnv<-round(mnv[,-1],2)

  mxv<-aggregate(x=D2[,var.names], by=list(GRP), FUN=max)
  mxv<-round(mxv[,-1],2)

  wgv<-aggregate(x=D2[,var.names], by=list(GRP), FUN=var)
  wgv<-round(wgv[,-1],2)

  var.summ.stats<-list(Mean=means,Medians=med, St_Dev=stdev,St_Err=std.err,Coef_Var=CVar, Min=mnv, Max=mxv,
                       Var=wgv)
  #########################################################################
  summ.list<-list(MODEL_STATS=mod.stats, COORDINATES=som.class.xy, FREQUENCIES=freq.tab2, PROFILES=profiles, PREDICTIONS=som.variable,
                  PROFILE_DISTANCES=dist.summ, COMPONENT_EVALUATION=var.eval, MAP_ORGANIZATION=sp.cor.tab,
                  COMPONENT_STATISTICS=var.summ.stats)
  return(summ.list)

  }
