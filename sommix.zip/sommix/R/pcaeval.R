#'Explore variance-covariance structure with Principal Component Analysis
#'\code{pca.eval} explores statistical correlations of variables
#'@param data a data object
#'@param lab.cex sets label size
#'@return a plot of pca results
#'@export
pca.eval<-function(data, lab.cex=1){
  data.df=as.data.frame(data)
  vars=names(data.df)
  var.labs=ifelse(nchar(vars)<8,vars,substr(vars, 0,8))

  #Conduct PCA
  pca.mix<-prcomp(data, center=FALSE, scale=FALSE)

  pca.loadings<-round(pca.mix$rotation,2)
  pca.scores<-pca.mix$x

  #Export Results
  write.table(x=pca.loadings, file="pca.loadings.summ.csv", sep=",")
  write.table(x=pca.scores, file="pca.scores.csv", sep=",")

  #Explore the variance explained by each component
  pr.var=pca.mix$sdev^2
  #Calculate the proportion of variance explained
  pve=round(pr.var/sum(pr.var),2)

  par(mfrow=c(2,2), mar=c(5,4,2,1), ask=FALSE, family='serif', cex=0.75, pty="m")
  #Plot the component Standard deviations to see which are useful
  plot(pca.mix$sdev^2, pch=20, ylab="Eigenvalue", xlab="Principal Component",
       cex=lab.cex, type="b", main="a) PCA Scree Plot", col="darkblue")
  abline(h=1, col="darkgrey", lty=2)


  plot(pve, xlab="Principal Component", ylab="Proportion of Variance", ylim=c(0,1), type='b',
       pch=20, col="darkblue", main="b) Variance Explained", cex=lab.cex)
  points(cumsum(pve), type='b',pch=20, col="darkred")
  abline(h=cumsum(pve)[2], col="darkgrey", lwd=2, lty=2)
  legend("bottomright", pch=20, col=c("darkblue", "darkred"), legend=c("Individual", "Cumulative"))


  PC1<-pca.loadings[,1]
  barplot(PC1, main="c) PC1 Loadings", ylim=c(-1,1), las=2,
          names.arg=var.labs, cex.names=lab.cex, col="lightgrey")
  box()


  PC2<-pca.loadings[,2]
  barplot(PC2, main="d) PC2 Loadings", ylim=c(-1,1), las=2,
          names.arg=var.labs, cex.names=lab.cex, col="lightgrey")
  box()


  #pca.out<-list(LOADINGS=pca.loadings, SCORES= pca.scores)
  #pca.out

}
