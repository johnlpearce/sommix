#Generate Base Plot
#'\code{plot.somgrid} sets plot base
#'@param x a SOM object
#'@param xlim sets x limits
#'@param ylim sets y limits
#'@return sets up base plot frame
#'@export
plot.somgrid <- function(x, xlim, ylim, ...){
  ## The following two lines leave equal amounts of space on both
  ## sides of the plot if no xlim or ylim are given
  if (missing(xlim)) xlim <- c(0, max(x$pts[,1]) + min(x$pts[,1]))
  if (missing(ylim)) ylim <-  c(max(x$pts[,2]) + min(x$pts[,2]), 0)
  eqscplot(xlim, ylim, axes = FALSE,
           type = "n", xlab = "", ylab = "", ...)
}



#Generate radial segment plot for SOM profiles
#'\code{map.profile.plot} plots SOM profiles as radial segment diagrams with relative frequencies
#'@param som.obj a SOM object
#'@param lab.cex sets label size
#'@param legend.loc passes location to legend()
#'@param leg.sym.cex passes symbol size to legend()
#'@param leg.lab.cex passes text size to legend()
#'@param col.mod sets color for segments
#'@return sets up base plot frame
#'@export

map.profile.plot<-function(som.obj, lab.cex=1, legend.loc="bottom",
                           leg.sym.cex=1, leg.lab.cex=1,
                           col.mod=diverge_hcl(p, h=c(130,43, c=100, I=c(70,90)))){
  #Extract info for plotting
  somx<-som.obj$grid$xdim
  somy<-som.obj$grid$ydim
  profiles<-as.data.frame(som.obj$codes)
  som.summ<-som.fit.summ(som.obj)
  som.topo=som.obj$grid$topo

  #Set labels
  IDs=1:dim(profiles)[1]
  p=dim(profiles)[2]
  var.labs<-dimnames(profiles)[[2]]

  #Extract data with Class Assignments
  FREQ<-som.summ$FREQUENCIES$FREQ
  N<-som.summ$FREQUENCIES$N

  #Set Color Scheme
  color.mod=col.mod

  #Create Profile plot
  par(mfrow=c(1,1),mar=c(.6,.6,.6,.6), family="serif", pty="m", cex=0.75)
  plot.somgrid(som.obj$grid)
  stars(x=som.summ$PROFILES, locations=coordinates(som.summ$COORDINATES[,3:4]),
        draw.segments=TRUE, axes=FALSE, scale=TRUE,
        len = 0.4, col.segments=color.mod,
        labels=NULL,ylim=c(0.5,somy), xlim=c(0.5,somx+.5), add=TRUE)

  symbols(coordinates(som.summ$COORDINATES[,3:4]),
          squares = rep(1, nrow(som.summ$COORDINATES)),
          inches = FALSE, add = TRUE,
          fg = "black", bg = NA)

  axis(1, at=som.obj$grid$pts[,1], pos=0.5)
  text(x=mean(som.summ$COORDINATES$X), y=0.2, labels="SOM X")
  axis(2, at=som.obj$grid$pts[,2], pos=0.5)
  text(x=0.25, y=mean(som.summ$COORDINATES$Y), labels="SOM Y", srt=90)

  text(x=som.summ$COORDINATES$X, y=som.summ$COORDINATES$Y+.4,
       labels=paste("[",som.summ$COORDINATES$X,",", som.summ$COORDINATES$Y ,"]", sep=""),
       font=2, cex=lab.cex+.5)

  text(x=som.summ$COORDINATES$X+.4, y=som.summ$COORDINATES$Y-.35,
       labels=paste(FREQ,"%", sep=""),
       font=2, cex=lab.cex)

  text(x=som.summ$COORDINATES$X+.4, y=som.summ$COORDINATES$Y-.45,
       labels=paste("n=", N, sep=""),
       font=2, cex=lab.cex)

  min.x<-min(som.summ$COORDINATES[,3])
  min.y<-min(som.summ$COORDINATES[,4])

  legend(legend.loc, legend=var.labs, pch=15,
         col=col.mod,
         pt.cex=leg.sym.cex, cex=leg.lab.cex, angle=45, ncol=round(length(var.labs)/2),
         inset=0)
}

############################################################################################
############################################################################################
#Bar Plot with error bars of Profiles
#A function to add arrows on the chart
#'\code{error.bar} adds error bars to bar plots
#'@param x x coordinate
#'@param y y coordinate
#'@param upper upper bar range
#'@param lower lower bar range
#'@param length arrow length
#'@return plot error bars
#'@export
error.bar <- function(x, y, upper, lower=upper, length=0.01,...){
  arrows(x,y+upper, x, y-lower, angle=90, code=3, length=length, col="darkgrey", ...)
}

############################################################################################
############################################################################################
#Generate bar plots with error bars for SOM profiles
#'\code{map.bar.plot} plots SOM profiles as radial segment diagrams with relative frequencies
#'@param som.obj a SOM object
#'@param lab.cex sets label size
#'@param label.loc sets location of labels
#'@param legend.cex passes text size to legend()
#'@param col.mod sets color for segments
#'@return bar plots of SOM profiles along SOM grid
#'@export

map.bar.plot<-function(som.obj, lab.cex=1, label.loc="bottom", legend.cex=1,
                       col.mod=diverge_hcl(p, h=c(130,43, c=100, I=c(70,90)))){
  #Get summary output
  som.summ<-som.fit.summ(som.obj)
  #Get SOM Dimensions
  somx<-som.obj$grid$xdim
  somy<-som.obj$grid$ydim
  #Get SOM Codes
  profiles<-as.data.frame(som.obj$codes)
  profiles

  #Get variable names
  var.names<-names(profiles)
  n.col=length(var.names)
  p=n.col

  #Set Bar Color Model
  color.mod<-col.mod

  #Extract data with Class Assignments
  FREQ<-som.summ$FREQUENCIES$FREQ
  N<-som.summ$FREQUENCIES$N
  #Generate a layout matrix
  par(mar=c(.6,3,2,.6), pty="m", cex=0.75)
  M<-matrix(data=1:(somx*somy),
            nrow=somy, ncol=somx, byrow=TRUE)
  M1=apply(t(M),1,rev)

  M2<-rbind(M1, rep(1+(somx*somy),somx))

  mf <- layout(M2, widths = rep(1, ncol(M2)),
               heights = c(rep(1, nrow(M2)-1), 0.5), respect = FALSE)
  #layout.show(mf)

  #Generate barplots
  plot.data<-som.summ$COMPONENT_STATISTICS$Mean
  plot.error<-som.summ$COMPONENT_STATISTICS$St_Dev
  plot.labs<-paste(som.summ$COORDINATES$X, ",",som.summ$COORDINATES$Y, sep="")

  for(i in 1:(somx*somy)){
    plot.vals<-as.numeric(plot.data[i,])
    plot.err<-as.numeric(plot.error[i,])

    bp<-barplot(plot.vals, col=color.mod, axes=TRUE, axisnames=FALSE,
                ylim=c(1.2*min(plot.data), 1.2*max(plot.data)))
    error.bar(bp,plot.vals,plot.err)
    abline(h=0, lty=2, col="black")
    title(main=paste("[", plot.labs[i] ,"]", sep=""), font=2, cex.main=lab.cex+.5)
    legend(legend=c(paste(FREQ[i], "%",sep=""), paste("n=",N[i],sep="")), cex=lab.cex,text.font=2,
           x=label.loc, bty="n", horiz=FALSE)
    box()
    box(which="outer")

  }

  box(which="outer")
  par(mar=c(.1,.1,.1,.1))
  plot(x=1:n.col, y=rep(1.25,n.col), pch=15, cex=legend.cex+1,
       col=color.mod,
       xlab=var.names, ylim=c(1,1), axes=FALSE)
  box()
  box(which="outer")
  text(x=1:n.col, y=rep(1,n.col), var.names, pos=1, cex=legend.cex, srt=90)

}
############################################################################################
############################################################################################
#Generate Component Plot
#Generate bar plots with error bars for SOM profiles
#'\code{map.comp.plot} plots component planes across SOM grid
#'@param som.obj a SOM object
#'@param col.mod sets color for segments
#'@param border.style sets boundary style for each profile
#'@return component plane plots of SOM profiles along SOM grid
#'@export

map.comp.plot<-function(som.obj, col.mod=diverging_hcl, border.style="straight"){
  #Extract info for plotting
  somx<-som.obj$grid$xdim
  somy<-som.obj$grid$ydim
  profiles<-as.data.frame(som.obj$codes)
  som.summ<-som.fit.summ(som.obj)

  #Set labels
  IDs=1:dim(profiles)[1]
  p=dim(profiles)[2]
  var.labs<-dimnames(profiles)[[2]]
  color.mod=col.mod

  #Standardized component plots
  par(mfrow=c(round(sqrt(p)),round(sqrt(p))), mar=c(1,4,2,1), family='serif', cex=0.75)
  for(i in 1:length(var.labs)){
    plot(som.obj, type="property", property=profiles[,i],
         main=var.labs[i], palette.name=color.mod, shape=border.style)
    axis(1, at=som.obj$grid$pts[,1], pos=0.5)
    axis(2, at=som.obj$grid$pts[,2], pos=0.5)
  }

}
############################################################################################
############################################################################################
#Map Fit Evaluation Functions
#Generate evaluatio plots of SOM model
#'\code{map.fit.plots} plots evaluation of SOM profiles using MDS, Sammons mapping, kmeans and PCA
#'@param som.obj a SOM object
#'@param lab.cex sets label size
#'@return a range of evaluation plots of SOM Model
#'@export

map.fit.plots<-function(som.obj, lab.cex=1){
  #Extract data
  data=data.frame(som.obj$data)
  var.names<-names(data)
  n.obs=dim(data)[1]
  n.vars=dim(data)[2]

  #set Data distance matrix
  dist.mat<-dist(x=data, method="euclidean")

  #Extract summary
  som.summ<-som.fit.summ(som.obj)

  #Get SOM Dimensions
  somx<-som.obj$grid$xdim
  somy<-som.obj$grid$ydim
  k=somx*somy

  #Get SOM Profiles
  som.profiles<-data.frame(som.obj$codes)
  som.coords<-som.obj$grid$pts
  row.names(som.profiles)<-paste(som.obj$grid$pts[,1], som.obj$grid$pts[,2], sep="")
  som.class<-som.obj$unit.classif

  set.seed(100)
  k.mod<-kmeans(x=data, centers=k, nstart=10, algorithm="Hartigan-Wong",
                iter.max=length(som.obj$changes))
  k.profiles=data.matrix(k.mod$centers)
  k.class=k.mod$cluster

  #Compare class assigments for k-means and SOM
  class.comp=cluster.stats(d=dist.mat, clustering=som.class, alt.clustering = k.class, compareonly=TRUE)
  class.comp<-data.frame(class.comp)
  colnames(class.comp)<-c("Rand Index", "Meila's VI")

  #Summarize PCA Scores by SOM Class
  pca.mix<-prcomp(data, center=FALSE, scale=FALSE)

  pca.loadings<-round(pca.mix$rotation,2)

  pc1.sc<-pca.mix$x[,1]
  pc1.som<-aggregate(pc1.sc, by=list(som.class), FUN=mean)
  pc1.som.summ<-pc1.som[,-1]
  pc2.sc<-pca.mix$x[,2]
  pc2.som<-aggregate(pc2.sc, by=list(som.class), FUN=mean)
  pc2.som.summ<-pc2.som[,-1]


  #Merge data for comparision
  data2=rbind(data, som.profiles,k.profiles)
  #set Data distance matrix
  dist.mat2<-dist(x=data2, method="euclidean")


  par(mfrow=c(3,2), mar=c(2.5,2,1,.5), ask=FALSE, family='serif', pty="m", cex=0.75)

  #Apply Ward's Clustering to SOM map
  h.som<-hclust(dist(som.profiles, method="euclidean"), method="ward.D2")
  plot(h.som, xlab="", main="a) Ward's Clustering of Profiles", sub="")
  box()

  #Generate a Sammon's Map to look at Map Distortion
  mapdist<-sammon(d=dist(som.profiles), y=data.matrix(som.coords),
                  k=2, niter=1000, trace=FALSE)
  plot(mapdist$points, pch=20, col="lightgrey", cex=5, xlab="Sammons X", ylab="Sammons Y",
       main="b) Sammons Map of Profiles")
  text(mapdist$points, labels = som.summ$COORDINATES$XY)


  #Apply multidimensional scaling to visualize clustering structure
  loc <- cmdscale(dist.mat2)
  mds.x <- loc[, 1]
  mds.y <- -loc[, 2] # reflect so North is at the top
  ## note asp = 1, to ensure Euclidean distances are represented correctly
  plot(mds.x, mds.y, type = "p", xlab = "MDS X", ylab = "MDS Y", asp = 1, axes = TRUE,
       main = "c) Profile Comparison", pch=c(rep(20, n.obs), rep(1,k), rep(3,k)),
       col=c(rep("lightgrey",n.obs), rep("black", k), rep("black", k)),
       cex=1.5)
  legend("bottomright", legend=c("OBS", "SOM", "K-Means"), pch=c(20,1,3),
         col=c("lightgrey","black","black"), cex=.75)

  box()

  ## SOM-Variable Evaluation
  mapvareval<-som.summ$COMPONENT_EVALUATION
  barplot(height=mapvareval$R, names.arg=mapvareval$Variable,
          las=2, cex.names=lab.cex, main="d) Variablewise Correlations", ylab="R", ylim=c(-1,1), col="lightgrey")
  abline(h=mean(mapvareval$R, na.rm=TRUE), col="darkgrey", lty=2)
  box()

  #PC1 Evaluation
  plot(som.obj, type="property", property=pc1.som.summ,
       main="g) Mean PC1 Score", palette.name=diverge_hcl, shape="straight")
  #axis(1, at=som.obj$grid$pts[,1], pos=0.5)
  #axis(2, at=som.obj$grid$pts[,2], pos=0.5)

  #PC2 Evaluation
  plot(som.obj, type="property", property=pc2.som.summ,
       main="h) Mean PC2 Score", palette.name=diverge_hcl, shape="straight")
  #axis(1, at=som.obj$grid$pts[,1], pos=0.5)
  #axis(2, at=som.obj$grid$pts[,2], pos=0.5)

  #print("Class agreement indices between SOM and k-means")
  #print(class.comp)

}
######
