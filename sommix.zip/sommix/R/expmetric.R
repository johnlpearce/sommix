############################################################################################
#Extract exposure variable from SOM analyses
############################################################################################
#Generate evaluatio plots of SOM model
#'\code{exp.metric} Extracts SOM output as multipollutant exposure metric
#'@param som.obj a SOM object
#'@return a dataframe of SOM classification and coordinate assignments
#'@export

exp.metric<-function(som.obj){
  #Extract Data
  som.data<-data.frame(som.obj$data)
  OBS<-as.numeric(row.names(som.data))

  #Extract SOM dimensions and create labels
  somx=som.obj$grid$xdim
  somy=som.obj$grid$ydim
  som.k=somx*somy
  XYs=paste(round(som.obj$grid$pts[,1],2),round(som.obj$grid$pts[,2],2), sep="")
  SOM_IDs=1:som.k
  #SOM Coordinates and reference table
  som.coords<-data.frame(X=som.obj$grid$pts[,1],Y=som.obj$grid$pts[,2])
  som.class.xy<-data.frame(SOM_ID=factor(SOM_IDs), XY=factor(XYs),X=as.numeric(som.obj$grid$pts[,1]),
                           Y=as.numeric(som.obj$grid$pts[,2]))

  #Extract class assignments
  unit.classif<-som.obj$unit.classif
  class.tab<-data.frame(OBS=OBS,SOM_ID=unit.classif)


  exp.tab<-merge(class.tab, som.class.xy, by="SOM_ID", all.x=TRUE)
  exp.tab$DISTANCE<-som.obj$distances
  exp.tab2<-exp.tab[order(exp.tab$OBS),]
  row.names(exp.tab2)<-exp.tab2$OBS

  return(exp.tab2)
}

